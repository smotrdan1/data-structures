public interface Array<T> extends ADTSet<T> {
    T get(int index);
}
