
public class BacktrackingBST implements Backtrack, ADTSet<BacktrackingBST.Node> {
    private Stack stack;
    private Stack redoStack;
    private int count; //count the number of backtracks that are done in a row
    BacktrackingBST.Node root = null;

    // Do not change the constructor's signature
    public BacktrackingBST(Stack stack, Stack redoStack) {
        this.stack = stack;
        this.redoStack = redoStack;
        count = 0;
    }

    public Node getRoot() {
        return root;
    }

    public Node search(int x) {
        BacktrackingBST.Node output = root;
        while(output != null && x != output.key) {
            if (x < output.key)
                output = output.left;
            else
                output = output.right;
        }
        return output;
    }

    public void insert(BacktrackingBST.Node z) {
        BacktrackingBST.Node ancestor = null;
        BacktrackingBST.Node son = root;
        while(son != null){
            ancestor = son;
            if(z.key < son.key)
                son = son.left;
            else
                son= son.right;
        }
        z.parent = ancestor;
        if(ancestor == null)
            root = z;
        else if(z.key < ancestor.key)
            ancestor.left = z;
        else
            ancestor.right = z;
        stack.push(z);
        stack.push('+');
        count = 0;
    }

    public void delete(Node x) {
        stack.push(x);
        if(x.left == null && x.right == null) {
            if(x.parent != null) {
                if (x.parent.key > x.key)
                    x.parent.left = null;
                else
                    x.parent.right = null;
            }
            else
                root = null;
            stack.push('-');
        }
        else if(x.left != null & x.right == null) {
            if(x.parent != null) {
                if (x.parent.key > x.key) {
                    x.parent.left = x.left;
                    stack.push('L');
                } else {
                    x.parent.right = x.left;
                    stack.push('l');
                }
            }
            else {
                root = x.left;
                stack.push('N');
            }
            x.left.parent = x.parent;
        }
        else if(x.left == null) {
            if(x.parent != null) {
                if (x.parent.key > x.key) {
                    x.parent.left = x.right;
                    stack.push('R');
                } else {
                    x.parent.right = x.right;
                    stack.push('r');
                }
            }
            else{
                root = x.right;
                stack.push('n');
            }
                x.right.parent = x.parent;
        }
        else {
            stack.pop();
            BacktrackingBST.Node suc = successor(x);
            delete(suc);
            stack.push(suc.right);
            stack.push(suc.parent);
            suc.left = x.left;
            suc.right = x.right;
            x.left.parent = suc;
            if(x.right != null)
                x.right.parent = suc;
            if(x.parent != null) {
                if (x.parent.key > x.key)
                    x.parent.left = suc;
                else
                    x.parent.right = suc;
            }
            else
                root = suc;
                suc.parent = x.parent;
            stack.push(x);
            stack.push('T');
        }
        count = 0;
    }

    public Node minimum() {
        if(root == null)
            return null;
        BacktrackingBST.Node output = root;
        while(output.left != null)
            output = output.left;
        return output;
    }



    public Node maximum() {
        if(root == null)
            return null;
        BacktrackingBST.Node output = root;
        while(output.right != null)
            output = output.right;
        return output;
    }

    public Node successor(Node x) {
        if(x.right != null){
            BacktrackingBST.Node output = x.right;
            while(output.left != null)
                output = output.left;
            return output;
        }
        BacktrackingBST.Node output = x.parent;
        BacktrackingBST.Node son = x;
        while(output != null && output.right != null && son.key == output.right.key){
            son = output;
            output = output.parent;
        }
        return output;
    }

    public Node predecessor(Node x) {
        if(x.left != null){
            BacktrackingBST.Node output = x.left;
            while(output.right != null)
                output = output.right;
            return output;
        }
        BacktrackingBST.Node output = x.parent;
        BacktrackingBST.Node son = x;
        while(output != null && output.left != null && son.key == output.left.key){
            son = output;
            output = output.parent;
        }
        return output;    }

    @Override
    public void backtrack() {
        int temp = count;
        if (!stack.isEmpty()) {
            char sign = (char)stack.pop();
            if (sign == '+') {
                BacktrackingBST.Node inserted = (Node) stack.pop();
                delete(inserted);
                stack.pop();
                redoStack.push(stack.pop());
                redoStack.push('+');
                System.out.println("backtracking performed");
            }
            else if (sign == '-') {
                BacktrackingBST.Node deleted = (Node) stack.pop();
                if(deleted.parent != null) {
                    if (deleted.parent.key > deleted.key)
                        deleted.parent.left = deleted;
                    else
                        deleted.parent.right = deleted;
                }
                else
                    root = deleted;
                redoStack.push(deleted);
                redoStack.push('-');
                System.out.println("backtracking performed");
            }
            else if(sign == 'L' | sign == 'l' | sign == 'R' | sign == 'r' | sign == 'N' | sign =='n') {
                BacktrackingBST.Node deleted = (Node) stack.pop();
                if (sign == 'L') {
                    deleted.left.parent = deleted;
                    deleted.parent.left = deleted;
                } else if (sign == 'l') {
                    deleted.left.parent = deleted;
                    deleted.parent.right = deleted;
                } else if (sign == 'R') {
                    deleted.right.parent = deleted;
                    deleted.parent.left = deleted;
                } else if (sign == 'r'){
                    deleted.right.parent = deleted;
                    deleted.parent.right = deleted;
                }else if (sign == 'N'){
                    deleted.left.parent = deleted;
                    root = deleted;
                }else {
                    deleted.right.parent = deleted;
                    root = deleted;
                }
                redoStack.push(deleted);
                redoStack.push('-');
                System.out.println("backtracking performed");
            }
            else if (sign == 'T') {
                BacktrackingBST.Node x = (Node)stack.pop();
                BacktrackingBST.Node suc = x.left.parent;
                suc.left.parent = x;
                if(suc.right != null)
                    suc.right.parent = x;
                if(suc.parent != null) {
                    if (suc.parent.key > suc.key)
                        suc.parent.left = x;
                    else
                        suc.parent.right = x;
                }
                else
                    root = x;
                suc.parent = (Node)stack.pop();
                suc.right = (Node)stack.pop();
                suc.left = null;
                backtrack();
                redoStack.pop();
                redoStack.pop();
                redoStack.push(x);
                redoStack.push('-');
            }
        }
        count = temp + 1;
    }

    @Override
    public void retrack() {
        if (count > 0){
            int temp = count;
            if ((char)redoStack.pop() == '+')
                insert((Node)redoStack.pop());
            else
                delete((Node)redoStack.pop());
            count = temp - 1;
        }
    }

    public void printPreOrder(){
        if(root != null) {
            System.out.print(root.key);
            if(root.left != null)
                root.left.printPreOrder();
            if(root.right != null)
                root.right.printPreOrder();
        }
    }

    @Override
    public void print() {
        printPreOrder();;
    }

    public static class Node{
        //These fields are public for grading purposes. By coding conventions and best practice they should be private.
        public BacktrackingBST.Node left;
        public BacktrackingBST.Node right;

        private BacktrackingBST.Node parent;
        private int key;
        private Object value;

        public Node(int key, Object value) {
            this.key = key;
            this.value = value;
        }

        public int getKey() {
            return key;
        }

        public Object getValue() {
            return value;
        }

        public void printPreOrder(){
            System.out.print(" "+ this.key);
            if(left != null)
                left.printPreOrder();
            if(right != null)
                right.printPreOrder();
        }
    }
}
