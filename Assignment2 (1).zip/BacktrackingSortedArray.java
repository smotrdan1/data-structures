import com.sun.deploy.security.SelectableSecurityManager;

public class BacktrackingSortedArray implements Array<Integer>, Backtrack {
    private Stack stack;
    private int[] arr;
    int head;
    // TODO: implement your code here

    // Do not change the constructor's signature
    public BacktrackingSortedArray(Stack stack, int size) {
        this.stack = stack;
        arr = new int[size];
        head = 0;
    }
    @Override
    public Integer get(int index){
        return arr[index];
    }

    @Override
    public Integer search(int x) {
        int start = 0;
        int end = head;
        while(start <= end){
            int mid = (start + end) / 2;
            if(arr[mid] == x)
                return mid;
            if(arr[mid] < x)
                start = mid + 1;
            else
                end = mid - 1;
        }
        return -1;
    }

    @Override
    public void insert(Integer x) {
        boolean inserted = false;
        stack.push(head);
        if(head == 0) {
            arr[head] = x;
            stack.push(arr[head]);
            stack.push('+');
            inserted = true;
        }
        for (int i = head - 1; i >= -1 & !inserted; i--) {
            if (i < 0 || arr[i] < x) {
                arr[i + 1] = x;
                stack.push(i + 1);
                stack.push('+');
                inserted = true;
            } else
                arr[i + 1] = arr[i];
            }
        head = head + 1;

    }


    @Override
    public void delete(Integer index) {
        stack.push(arr[index]);
        stack.push(index);
        stack.push('-');
        for(int i = index; i < head - 1; i = i + 1)
            arr[i] = arr[i + 1];
        head = head - 1;
    }

    @Override
    public Integer minimum() {
        return arr[0];
    }

    @Override
    public Integer maximum() {
        return arr[head - 1];
    }

    @Override
    public Integer successor(Integer index) {
        return arr[index + 1];
    }

    @Override
    public Integer predecessor(Integer index) {
        return arr[index - 1];
    }

    @Override
    public void backtrack() {
        if (!stack.isEmpty())
            if ((char) stack.pop() == '+') {
                int preIndex = (int)stack.pop();
                for (int i = preIndex; i < head - 1; i = i + 1)
                    arr[i] = arr[i + 1];
                head = head - 1;
                arr[head] = (int) stack.pop();
            }
            else {
                int preIndex = (int)stack.pop();
                for (int i = head - 1; i >= preIndex; i--) {
                    arr[i + 1] = arr[i];
                }
                arr[preIndex] = (int)stack.pop();
                head = head + 1;
            }
        System.out.println("backtracking performed");
    }

    @Override
    public void retrack() {
        // Do not implement anything here!!
    }

    @Override
    public void print() {
        for(int i = 0; i < head -1 ; i++)
            System.out.print(arr[i] + " ");
        System.out.print(arr[head - 1]);

    }
}
