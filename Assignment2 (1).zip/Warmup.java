import java.util.NoSuchElementException;

public class Warmup {
    public static int backtrackingSearch(int[] arr, int x, int fd, int bk, Stack myStack) {
        int index = 0;
        while(index < arr.length){
            for(int i = 0; i < fd; i = i + 1){
                myStack.push(arr[index]);
                if(arr[index] == x)
                    return index;
                if(index == arr.length - 1)
                    return -1;
                index = index + 1;
            }
            for(int i =0; i < bk; i = i + 1){
                myStack.pop();
                index = index - 1;
            }
        }
        return -1;
    }

    public static int consistentBinSearch(int[] arr, int x, Stack myStack) {
        int start = 0;
        int end = arr.length - 1;
        while(start <= end){
            int mid = (start + end) / 2;
            for(int i = 0; i < isConsistent(arr) & !myStack.isEmpty(); i++){ //use is empty because of the experimental isConsistent
                mid = (int)myStack.pop(); //returns the previous value of mid
                if(mid == start -1)
                    start = mid/2 - end;
                else
                    end = mid/2 - start;
            }
            myStack.push(mid);
            if(arr[mid] == x)
                return mid;
            if(arr[mid] < x)
                start = mid + 1;
            else
                end = mid - 1;
        }
        return -1;
    }

    private static int isConsistent(int[] arr) {
        double res = Math.random() * 100 - 75;

        if (res > 0) {
            return (int)Math.round(res / 10);
        } else {
            return 0;
        }
    }
}
