import java.util.LinkedList;

public class BacktrackingArray implements Array<Integer>, Backtrack {
    private Stack stack;
    private int[] arr;
    private int head;

    // Do not change the constructor's signature
    public BacktrackingArray(Stack stack, int size) {
        this.stack = stack;
        arr = new int[size];
        head = 0;
    }

    @Override
    public Integer get(int index){
        return arr[index];
    }

    @Override
    public Integer search(int x) {
        for(int i = 0; i < head; i++)
            if(arr[i] == x)
                return i;
            return -1;
    }

    @Override
    public void insert(Integer x) {
        stack.push(arr[head]);
        arr[head] = x;
        head = head + 1;
        stack.push('+');
    }

    @Override
    public void delete(Integer index) {
        stack.push(index);
        stack.push(arr[index]);
        if(index != head)
            arr[index] = arr[head-1];
        head = head -1;
        stack.push('-');
    }

    @Override
    public Integer minimum() {
        int min = arr[0];
        for(int i = 1; i < head; i = i + 1) {
            if (arr[i] < min)
                min = arr[i];
        }
        return min;
    }

    @Override
    public Integer maximum() {
        int max = arr[0];
        for(int i = 1; i < head; i = i + 1) {
            if (arr[i] > max)
                max = arr[i];
        }
        return max;
    }

    @Override
    public Integer successor(Integer index) {
        int suc = 0;
        for(int i = 1; i < head; i = i + 1) {
            if (arr[i] > arr[index] & arr[i] < arr[suc])
                suc = i;
        }
        if(arr[suc] == arr[index])
            suc = -1;
        return suc;
    }

    @Override
    public Integer predecessor(Integer index) {
        int suc = 0;
        for(int i = 1; i < head; i = i + 1) {
            if (arr[i] < arr[index] & arr[i] > arr[suc])
                suc = i;
        }
        if(arr[suc] == arr[index])
            suc = -1;
        return suc;
    }

    @Override
    public void backtrack() {
        if(!stack.isEmpty())
            if((char)stack.pop() == '+'){
                arr[head] = (int)stack.pop();
                head = head - 1;
        }
            else{
                int preValue = (int)stack.pop();
                arr[head] = arr[preValue];
                arr[preValue] = (int)stack.pop();
                head = head + 1;
        }
        System.out.println("backtracking performed");
    }

    @Override
    public void retrack() {
        // Do not implement anything here!!
    }

    @Override
    public void print() {
        for(int i = 0; i < head - 1 ; i++)
            System.out.print(arr[i] + " ");
        System.out.print(arr[head - 1]);

    }
}
